<?php

include_once NOIZZY_MUSIC_SHORTCODES_PATH . '/audio-playlist/functions.php';
include_once NOIZZY_MUSIC_SHORTCODES_PATH . '/audio-playlist/audio-playlist.php';