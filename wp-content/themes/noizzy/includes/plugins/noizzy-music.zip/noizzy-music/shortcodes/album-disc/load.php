<?php

include_once NOIZZY_MUSIC_SHORTCODES_PATH . '/album-disc/functions.php';
include_once NOIZZY_MUSIC_SHORTCODES_PATH . '/album-disc/album-disc.php';