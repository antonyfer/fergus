<div class="edge-audio-playlist-holder">
<iframe style="border: 0; width: 100%; height: 350px;"
src="<?php print $playlist_id_url ?>" seamless></iframe>
</div>