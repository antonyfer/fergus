<?php

include_once NOIZZY_MUSIC_SHORTCODES_PATH . '/bands-in-town/functions.php';
include_once NOIZZY_MUSIC_SHORTCODES_PATH . '/bands-in-town/bands-in-town.php';