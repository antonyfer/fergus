<div class="edge-audio-playlist-holder">
<iframe width="100%" height="350" scrolling="no" frameborder="no" 
src="<?php print $playlist_id_url ?>" ></iframe>
</div>