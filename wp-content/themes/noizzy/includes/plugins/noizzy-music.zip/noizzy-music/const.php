<?php

define('NOIZZY_MUSIC_VERSION', '1.0.1');
define('NOIZZY_MUSIC_ABS_PATH', dirname(__FILE__));
define('NOIZZY_MUSIC_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('NOIZZY_MUSIC_URL_PATH', plugin_dir_url( __FILE__ ));
define('NOIZZY_MUSIC_CPT_PATH', NOIZZY_MUSIC_ABS_PATH.'/post-types');
define('NOIZZY_MUSIC_ASSETS_URL_PATH', NOIZZY_MUSIC_URL_PATH.'/assets');
define('NOIZZY_MUSIC_MODULE_PATH', NOIZZY_MUSIC_ABS_PATH.'/modules');
define('NOIZZY_MUSIC_CPT_URL_PATH', NOIZZY_MUSIC_URL_PATH.'post-types');
define('NOIZZY_MUSIC_SHORTCODES_PATH', NOIZZY_MUSIC_ABS_PATH . '/shortcodes' );
define('NOIZZY_MUSIC_SHORTCODES_URL_PATH', NOIZZY_MUSIC_URL_PATH . 'shortcodes' );