<h5 class="edge-about-album-holder-title"><?php esc_html_e('About album', 'noizzy-music'); ?></h5>
<div class="edge-about-album-content">
	<?php the_content(); ?>
</div>