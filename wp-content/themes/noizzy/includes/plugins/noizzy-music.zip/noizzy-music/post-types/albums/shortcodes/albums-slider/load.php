<?php

require_once 'albums-slider.php';
require_once 'helper-functions.php';