<?php

require_once 'albums-player-slider.php';
require_once 'helper-functions.php';