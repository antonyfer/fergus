<?php
require_once 'artists-slider.php';
require_once 'helper-functions.php';