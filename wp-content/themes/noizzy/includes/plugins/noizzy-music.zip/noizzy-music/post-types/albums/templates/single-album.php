<?php

get_header();

noizzy_edge_get_title();

do_action('noizzy_edge_before_main_content');

noizzy_music_single_album();

get_footer();