<?php
require_once 'artists-list.php';
require_once 'helper-functions.php';