<?php

require_once 'album.php';
require_once 'helper-functions.php';