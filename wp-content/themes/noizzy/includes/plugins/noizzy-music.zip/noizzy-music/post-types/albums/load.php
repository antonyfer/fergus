<?php
include_once NOIZZY_MUSIC_CPT_PATH . '/albums/albums-register.php';
include_once NOIZZY_MUSIC_CPT_PATH . '/albums/helper-functions.php';
include_once NOIZZY_MUSIC_CPT_PATH . '/albums/artists-custom-fields.php';