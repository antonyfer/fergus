<div class="edge-controls">
    <!--close popup-->
    <span class="edge-control-button edge-control-button-back edge-icon-font-elegant icon_close"></span>

    <div class="edge-controls-navigate">
        <span class="edge-control-button edge-control-button-next lnr lnr-chevron-right">

        </span>
        <span class="edge-control-button edge-control-button-prev lnr lnr-chevron-left">

        </span>
    </div>
</div><!--  /controls -->