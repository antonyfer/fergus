<?php

include_once NOIZZY_CORE_CPT_PATH . '/team/team-register.php';
include_once NOIZZY_CORE_CPT_PATH . '/team/helper-functions.php';