<?php

get_header();

noizzy_edge_get_title();

do_action('noizzy_edge_before_main_content');

noizzy_core_get_single_portfolio();

get_footer();