<div class="edge-ps-info-item edge-ps-content-item">
    <?php the_content(); ?>
</div>