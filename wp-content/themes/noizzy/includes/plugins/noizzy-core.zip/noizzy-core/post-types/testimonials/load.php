<?php

include_once NOIZZY_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once NOIZZY_CORE_CPT_PATH . '/testimonials/helper-functions.php';