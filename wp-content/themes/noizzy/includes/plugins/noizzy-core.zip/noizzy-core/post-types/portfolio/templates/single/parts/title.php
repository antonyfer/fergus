<div class="edge-ps-title-wrapper">
    <h2 class="edge-ps-title"><?php echo esc_html( get_the_title() ); ?></h2>
</div>