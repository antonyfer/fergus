<?php

include_once NOIZZY_CORE_SHORTCODES_PATH . '/vertical-flow-slider/functions.php';
include_once NOIZZY_CORE_SHORTCODES_PATH . '/vertical-flow-slider/vertical-flow-slider.php';