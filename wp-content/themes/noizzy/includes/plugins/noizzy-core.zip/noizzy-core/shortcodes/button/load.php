<?php

include_once NOIZZY_CORE_SHORTCODES_PATH . '/button/functions.php';
include_once NOIZZY_CORE_SHORTCODES_PATH . '/button/button.php';