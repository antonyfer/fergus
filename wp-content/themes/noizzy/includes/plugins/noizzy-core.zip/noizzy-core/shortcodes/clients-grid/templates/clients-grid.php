<div class="edge-grid-row edge-clients-grid-holder <?php echo esc_attr($holder_classes); ?>">
    <?php echo do_shortcode($content); ?>
</div>