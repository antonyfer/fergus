<?php

include_once NOIZZY_CORE_SHORTCODES_PATH . '/interactive-links-showcase/functions.php';
include_once NOIZZY_CORE_SHORTCODES_PATH . '/interactive-links-showcase/interactive-links-showcase.php';