<?php

include_once NOIZZY_CORE_SHORTCODES_PATH . '/clients-grid/functions.php';
include_once NOIZZY_CORE_SHORTCODES_PATH . '/clients-grid/clients-grid.php';
include_once NOIZZY_CORE_SHORTCODES_PATH . '/clients-grid/clients-grid-item.php';