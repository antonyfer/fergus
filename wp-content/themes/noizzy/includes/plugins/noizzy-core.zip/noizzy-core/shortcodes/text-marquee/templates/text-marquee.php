<div class="edge-text-marquee <?php echo esc_attr( $holder_classes ); ?>" <?php echo noizzy_edge_inline_style( $text_styles ); ?> <?php echo noizzy_edge_get_inline_attrs( $text_data ); ?>>
	<span class="edge-marquee-element edge-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="edge-marquee-element edge-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  