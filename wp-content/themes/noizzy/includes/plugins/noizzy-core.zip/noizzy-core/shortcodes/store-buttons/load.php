<?php

include_once NOIZZY_CORE_SHORTCODES_PATH . '/store-buttons/functions.php';
include_once NOIZZY_CORE_SHORTCODES_PATH . '/store-buttons/store-buttons.php';